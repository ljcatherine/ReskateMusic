# ReskateMusic 0.1

Custom native ReSkate runtime extension, built from Dingo-Shenanigans/ReSkate commit 6c45e9666dcdea6577248f6ab7f3111de48b6039 (15 October 2026). Game build: 25414733. Windows x64.

## Install

Close Skate. Back up your existing installation, then replace its ReSkate.dll with this one. This is a runtime replacement, not a Mods-folder asset mod. Keep the launcher and support files belonging to the matching upstream version. Alternatively run:

```powershell
.\Install.ps1 -ReSkateFolder 'C:\Games\ReSkate'
```

The installer verifies the Skate executable hash, saves the old DLL beside it and disables launcher auto-updates after backing up its settings. Restore that backup to uninstall. Automatic launcher updates can replace the custom runtime; do not apply this DLL to a different game build.

## Use

Open Skate's pause menu, then **MOD OPTIONS > MUSIC**. Mouse, keyboard navigation and controller navigation use ReSkate's existing pause-menu controls. Search and seeking need typing; press Enter to submit.

- Play/pause, next and previous through the desktop media session.
- Spotify account setup, playlists, Liked Songs and individual track selection.
- Search songs/artists, play search results, add search results to Spotify's queue.
- Queue display, shuffle on/off, repeat song/all/off, seek to a position in seconds.
- In-game music volume. Select Spotify in the game's music screen to route audio through the game; this slider adjusts that routed audio.
- Small translucent now-playing card in the bottom right, with song, artist and paused status. It never captures input. Its visibility preference is saved.

Start Spotify on this PC and play a song for basic media controls and metadata. Open **Spotify setup / sign in** for library/API access. Register your own Spotify developer app with redirect URI `http://127.0.0.1:47824/callback`, supply its client ID in setup and sign in. No client secret is required; the inherited integration uses PKCE and protects saved refresh credentials with Windows DPAPI. API playback actions require Spotify Premium and an active device. Spicetify is not required.

## Scope and validation

This is a music player integration, not a complete embedded copy of the Spotify application. Playlist editing, recommendations, artist/album pages, podcasts and account management are not implemented. The inherited library fetch lists up to 50 playlists and the first 50 tracks of each; search lists ten matches. Spotify may limit which playlists a development app can access. Playback actions target the active Spotify device; use your desktop Spotify app as that device so the song matches the local now-playing card.

Build verification and game testing status are recorded in BUILD-STATUS.txt. Compilation alone does not verify runtime behavior in Skate or authenticated Spotify requests.

## Source / license

ReSkate is GPL-3.0; see LICENSE. Complete corresponding source is supplied in the sibling ReskateMusic-source.zip. The local working source is ../../upstream. Rebuild with Visual Studio 2022 C++ tools, Windows SDK and CMake:

```powershell
cmake --preset vs2022-x64
cmake --build --preset release --target dingosdk_runtime --parallel 8
```

Upstream: https://github.com/Dingo-Shenanigans/ReSkate
Spotify playback requirements: https://developer.spotify.com/documentation/web-api/reference/start-a-users-playback
